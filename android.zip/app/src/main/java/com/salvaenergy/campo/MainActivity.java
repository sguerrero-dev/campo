package com.salvaenergy.campo;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.GeolocationPermissions;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private static final String URL = "https://sguerrero-dev.github.io/campo/?app=1";
    private static final int REQ_UBI = 7;

    private WebView web;
    private GeolocationPermissions.Callback geoCb;
    private String geoOrigen;
    private AlertDialog dialogo;
    private boolean pedido = false;
    private boolean esperando = false;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setGeolocationEnabled(true);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                String h = u.getHost() == null ? "" : u.getHost();
                if (h.endsWith("github.io") || h.endsWith("google.com") || h.endsWith("googleusercontent.com")) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception e) { }
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback cb) {
                if (tienePermiso()) {
                    cb.invoke(origin, true, true);
                } else {
                    geoOrigen = origin;
                    geoCb = cb;
                    pedirPermiso();
                }
            }
        });

        if (b == null) web.loadUrl(URL); else web.restoreState(b);
        if (!tienePermiso()) pedirPermiso();
    }

    @Override
    protected void onSaveInstanceState(Bundle o) {
        super.onSaveInstanceState(o);
        web.saveState(o);
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
        if (tienePermiso()) {
            if (!gpsEncendido()) avisoGps();
            else { cerrarDialogo(); reintentarEnPagina(); }
        } else if (pedido && !esperando && !shouldShowRequestPermissionRationale(Manifest.permission.ACCESS_FINE_LOCATION)) {
            avisoBloqueado();
        }
    }

    @Override
    protected void onPause() {
        web.onPause();
        super.onPause();
    }

    private boolean tienePermiso() {
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
            || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void pedirPermiso() {
        pedido = true;
        esperando = true;
        requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_UBI);
    }

    private boolean gpsEncendido() {
        LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (lm == null) return true;
        try {
            return lm.isProviderEnabled(LocationManager.GPS_PROVIDER) || lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
        } catch (Exception e) { return true; }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code != REQ_UBI) return;
        esperando = false;
        boolean ok = tienePermiso();
        if (geoCb != null) { geoCb.invoke(geoOrigen, ok, ok); geoCb = null; }
        if (ok) {
            if (!gpsEncendido()) avisoGps();
            else { cerrarDialogo(); reintentarEnPagina(); }
        } else if (shouldShowRequestPermissionRationale(Manifest.permission.ACCESS_FINE_LOCATION)) {
            mostrar("Ubicación obligatoria",
                "Para trabajar tus tareas debes permitir la ubicación.",
                "Permitir ubicación", () -> pedirPermiso());
        } else {
            avisoBloqueado();
        }
    }

    private void avisoBloqueado() {
        mostrar("Activa la ubicación",
            "La ubicación está bloqueada para esta app. Toca \"Abrir ajustes\", entra a Permisos › Ubicación y elige \"Permitir solo con la app en uso\".",
            "Abrir ajustes", () -> {
                Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", getPackageName(), null));
                startActivity(i);
            });
    }

    private void avisoGps() {
        mostrar("Enciende la ubicación",
            "La ubicación (GPS) del celular está apagada. Toca \"Activar ubicación\" y enciéndela.",
            "Activar ubicación", () -> {
                try { startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)); }
                catch (Exception e) { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
            });
    }

    private void mostrar(String titulo, String texto, String boton, Runnable accion) {
        cerrarDialogo();
        dialogo = new AlertDialog.Builder(this)
            .setTitle(titulo)
            .setMessage(texto)
            .setCancelable(false)
            .setPositiveButton(boton, (d, w) -> accion.run())
            .create();
        dialogo.show();
    }

    private void cerrarDialogo() {
        if (dialogo != null && dialogo.isShowing()) dialogo.dismiss();
        dialogo = null;
    }

    private void reintentarEnPagina() {
        web.evaluateJavascript(
            "(function(){var u=document.getElementById('ubi');if(window.permitirUbicacion&&u&&u.style.display!=='none'){permitirUbicacion();}})()", null);
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
